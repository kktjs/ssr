Basic Example
---

The [react](https://github.com/facebook/react) base application.

## Development

Runs the project in development mode.  

```bash
npm run start
```

Runs Node Server

```bash
npm run server
```

## production

Builds the app for production to the build folder.

```bash
npm run build
```

The build is minified and the filenames include the hashes.
Your app is ready to be deployed!
