import login from "./login";
import demo from "./demo";
// @ts-ignore
import { init } from '@rematch/core';
import loading from '@rematch/loading';
export const models = {
  login,
  demo
};
export const store = init({
  models,
  plugins: [loading()]
});
export const {
  dispatch,
  addModel
} = store;
export default store;