import React from 'react';
import ReactDOM from 'react-dom';
// import App from './routes';
// const renderMethod = !!module.hot ? ReactDOM.render : ReactDOM.hydrate

ReactDOM.render(<div>222</div>, document.getElementById('root'));

// if (module.hot) {
//   module.hot.accept();
// }
